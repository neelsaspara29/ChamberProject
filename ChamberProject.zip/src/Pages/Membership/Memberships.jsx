import React from 'react'
import MembershipDetail from './MembershipDetail'

const Memberships = () => {
    return (
        <div>
            <MembershipDetail />
        </div>
    )
}

export default Memberships