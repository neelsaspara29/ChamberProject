import React, { useState } from "react";
import { ApiGet, ApiPost } from "../../Helper/API/Apidata";
import Button from "react-bootstrap/Button";
import LoadingSpinner from "./LoadingSpinner";
import { useNavigate } from "react-router-dom";

const MembershipDetail = () => {
  const [data, setData] = useState("");
  const [id, setId] = useState("");
  const [amount, setAmount] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPayNow, setShowPayNow] = useState(false);
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    // const id = "646b4de8a292b3b85fc48b56";
    e.preventDefault();
    ApiGet(`/member/uniqueId/${id}`)
      .then((response) => {
        console.log("##$$", response.data);
        setData(response?.data?.data?.pendingAmount);
        console.log("data", response?.data?.data?.pendingAmount);
      })
      .catch(() => {
        setErrorMessage("Unable to fetch user list");
      });
    setShowPayNow(true);
  };

  const handlePayment = (e) => {
    e.preventDefault();
    console.log("Payment initiated");
    setIsLoading(true);

    const postData = {
      userId: "SCCI_39481",
      amount: data,
    };

    ApiPost("/payment", postData)
      .then((response) => {
        console.log("response", response);
        console.log("id", response?.data?.data?.txnData?.txntoken);
        openJsCheckoutPopup(
          response?.data?.data?.txnData?.orderid,
          response?.data?.data?.txnData?.amount,
          response?.data?.data?.txnData?.txntoken
        );
        // verifySignature(
        //   response?.data?.data?.txnData?.orderid,
        //   response?.data?.data?.txnData?.amount,
        //   response?.data?.data?.txnData?.txntoken
        // )
        setAmount(response);
        console.log("data", amount);
      })
      .catch(() => {
        setErrorMessage("Unable to fetch user list");
      });
  };

  function openJsCheckoutPopup(orderId, amount, txnToken) {
    var config = {
      root: "",
      flow: "DEFAULT",
      data: {
        orderId: orderId,
        token: txnToken,
        tokenType: "TXN_TOKEN",
        amount: amount,
      },
      merchant: {
        redirect: true,
      },
      handler: {
        notifyMerchant: function (eventName, data) {
          console.log("notifyMerchant handler function called");
          console.log("eventName => ", eventName);
          console.log("data => ", data);
        },
      },
    };
    if (window.Paytm && window.Paytm.CheckoutJS) {
      console.log("pop");
      window.Paytm.CheckoutJS.init(config)
        .then(function onSuccess() {
          window.Paytm.CheckoutJS.invoke();
          setIsLoading(false);
          navigate("/success");
          console.log("first");
        })
        .catch(function onError(error) {
          console.log("error => ", error);
          navigate("/failure");
        });
    }
  }

  return (
    <div>
      <div className="d-flex justify-content-center align-items-center mt-5">
        <div
          style={{
            background: "#fff",
            boxShadow: "0 0 5px #aaa",
            padding: "20px 30px",
          }}
        >
          <div className="form-group text-center d-flex align-items-center">
            <div className="input-group mb-3">
              <div className="input-group-prepend">
                <span className="input-group-text">ID</span>
              </div>
              <input
                type="text"
                className="form-control"
                aria-label="User Id"
                value={id}
                onChange={(e) => setId(e.target.value)}
              />
              <div className="input-group-append">
                <button className="btn btn-primary" onClick={handleSubmit}>
                  Submit
                </button>
              </div>
            </div>
          </div>
          <div className="text-center mt-4"></div>
          <div className="d-flex justify-content-between align-items-center">
            <div className="amount">Amount: {data}</div>
            {showPayNow && (
              <Button
                className="btn btn-primary"
                onClick={handlePayment}
                disabled={isLoading}
              >
                {isLoading ? <LoadingSpinner /> : "Pay Now"}
              </Button>
              // {errorMessage && <div style={{ color: "red" }}>{errorMessage}</div>}
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MembershipDetail;
