import React from "react";

const SuccessPage = () => {
  return (
    <div>
      <h1>Payment Successful!</h1>
     
      {/* Add content for the success page */}
    </div>
  );
};

export default SuccessPage;
