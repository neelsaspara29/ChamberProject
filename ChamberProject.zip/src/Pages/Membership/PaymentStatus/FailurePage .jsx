import React from "react";

const FailurePage = () => {
  return (
    <div>
      <h1>Payment Failed!</h1>
      <h1>hello payment</h1>
      {/* Add content for the failure page */}
    </div>
  );
};

export default FailurePage;
